/* 
 * File:   histogram.h
 * Author: Tajbir
 *
 * Created on May 20, 2013, 9:42 AM
 */

#ifndef HISTOGRAM_H
#define	HISTOGRAM_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* HISTOGRAM_H */

